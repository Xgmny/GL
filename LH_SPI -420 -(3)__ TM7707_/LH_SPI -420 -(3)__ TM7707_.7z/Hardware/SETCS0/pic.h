#ifndef __PIC_H
#define __PIC_H	 




void FIRST(void);
void FIRST_2(void);
void ONE(void);
void TWO(void);
void THERR(void);
void FOUR(void);
void FIVE(void);
void SIX(void);
void SEV(void);
void MENU(void);
void CAN_SET(void);

#endif
